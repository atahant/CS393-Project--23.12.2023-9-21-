package com.project.cakmazon.services;

import com.project.cakmazon.dto.CartItemDTO;
import com.project.cakmazon.dto.ProductDTO;
import com.project.cakmazon.mapper.CartItemMapper;
import com.project.cakmazon.mapper.ProductMapper;
import com.project.cakmazon.model.CartItem;
import com.project.cakmazon.repo.CartItemRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class CartItemServiceTest {

    @Mock
    private CartItemRepository cartItemRepository;

    @Mock
    private ProductService productService;

    @Mock
    private CartItemMapper cartItemMapper;

    @Mock
    private ProductMapper productMapper;

    @InjectMocks
    private CartItemService cartItemService;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testGetAllCartItems() {
        
        CartItem cartItem1 = new CartItem();
        cartItem1.setCartItemId(1L);
        CartItem cartItem2 = new CartItem();
        cartItem2.setCartItemId(2L);

        
        CartItemDTO cartItemDTO1 = new CartItemDTO();
        cartItemDTO1.setCartItemId(1L);
        CartItemDTO cartItemDTO2 = new CartItemDTO();
        cartItemDTO2.setCartItemId(2L);

        when(cartItemRepository.findAll()).thenReturn(Arrays.asList(cartItem1, cartItem2));
        when(cartItemMapper.toDTOList(Arrays.asList(cartItem1, cartItem2))).thenReturn(Arrays.asList(cartItemDTO1, cartItemDTO2));

        List<CartItemDTO> result = cartItemService.getAllCartItems();

        assertEquals(2, result.size());
        assertEquals(cartItemDTO1, result.get(0));
        assertEquals(cartItemDTO2, result.get(1));
    }

    @Test
    public void testGetCartItemById() {
        Long cartItemId = 1L;

        
        CartItem cartItem = new CartItem();
        cartItem.setCartItemId(cartItemId);

        
        CartItemDTO cartItemDTO = new CartItemDTO();
        cartItemDTO.setCartItemId(cartItemId);

        when(cartItemRepository.findById(cartItemId)).thenReturn(Optional.of(cartItem));
        when(cartItemMapper.toDTO(cartItem)).thenReturn(cartItemDTO);

        Optional<CartItemDTO> result = cartItemService.getCartItemById(cartItemId);

        assertTrue(result.isPresent());
        assertEquals(cartItemDTO, result.get());
    }

    @Test
    public void testSaveCartItem() {
        
        CartItemDTO cartItemDTO = new CartItemDTO();
        cartItemDTO.setCartItemId(1L);

       
        ProductDTO productDTO = new ProductDTO();
        productDTO.setProductId(1L);

       
        CartItem cartItem = new CartItem();
        cartItem.setCartItemId(1L);

        when(productService.getProductDTOById(cartItemDTO.getProduct().getProductId())).thenReturn(productDTO);
        when(cartItemMapper.toEntity(cartItemDTO)).thenReturn(cartItem);
        when(productMapper.toEntity(productDTO)).thenReturn(new Product()); // or any mock Product entity
        doNothing().when(cartItemRepository).save(cartItem);

        cartItemService.saveCartItem(cartItemDTO);

        verify(cartItemRepository, times(1)).save(cartItem);
    }

    @Test
    public void testDeleteCartItem() {
        Long cartItemId = 1L;

        cartItemService.deleteCartItem(cartItemId);

        verify(cartItemRepository, times(1)).deleteById(cartItemId);
    }

    @Test
    public void testUpdateCartItem() {
        Long cartItemId = 1L;

      
        CartItemDTO existingCartItemDTO = new CartItemDTO();
        existingCartItemDTO.setCartItemId(cartItemId);

        CartItemDTO updatedCartItemDTO = new CartItemDTO();
        updatedCartItemDTO.setQuantity(2);

        when(cartItemService.getCartItemById(cartItemId)).thenReturn(Optional.of(existingCartItemDTO));
        doNothing().when(cartItemRepository).saveCartItem(existingCartItemDTO);

        cartItemService.updateCartItem(cartItemId, updatedCartItemDTO);

        assertEquals(2, existingCartItemDTO.getQuantity());
    }

}
