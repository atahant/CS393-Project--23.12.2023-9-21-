package com.project.cakmazon.services;

import com.project.cakmazon.dto.CustomerDTO;
import com.project.cakmazon.mapper.CustomerMapper;
import com.project.cakmazon.model.Customer;
import com.project.cakmazon.repo.CustomerRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class CustomerServiceTest {

    @Mock
    private CustomerRepository customerRepository;

    @Mock
    private CustomerMapper customerMapper;

    @InjectMocks
    private CustomerService customerService;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testGetAllCustomers() {
        
        Customer customer1 = new Customer();
        customer1.setCustomerId(1L);
        Customer customer2 = new Customer();
        customer2.setCustomerId(2L);

        CustomerDTO customerDTO1 = new CustomerDTO();
        customerDTO1.setCustomerId(1L);
        CustomerDTO customerDTO2 = new CustomerDTO();
        customerDTO2.setCustomerId(2L);

        when(customerRepository.findAll()).thenReturn(Arrays.asList(customer1, customer2));
        when(customerMapper.toDTOList(Arrays.asList(customer1, customer2))).thenReturn(Arrays.asList(customerDTO1, customerDTO2));

        List<CustomerDTO> result = customerService.getAllCustomers();

        assertEquals(2, result.size());
        assertEquals(customerDTO1, result.get(0));
        assertEquals(customerDTO2, result.get(1));
    }

    @Test
    public void testGetCustomerById() {
        Long customerId = 1L;

        Customer customer = new Customer();
        customer.setCustomerId(customerId);

        CustomerDTO customerDTO = new CustomerDTO();
        customerDTO.setCustomerId(customerId);

        when(customerRepository.findById(customerId)).thenReturn(Optional.of(customer));
        when(customerMapper.toDTO(customer)).thenReturn(customerDTO);

        Optional<CustomerDTO> result = customerService.getCustomerById(customerId);

        assertTrue(result.isPresent());
        assertEquals(customerDTO, result.get());
    }

    @Test
    public void testSaveCustomer() {
      
        CustomerDTO customerDTO = new CustomerDTO();
        customerDTO.setCustomerId(1L);

        Customer customer = new Customer();
        customer.setCustomerId(1L);

        when(customerMapper.toEntity(customerDTO)).thenReturn(customer);
        when(customerRepository.save(customer)).thenReturn(customer);

        CustomerDTO result = customerService.saveCustomer(customerDTO);

        assertEquals(customerDTO, result);
    }

    @Test
    public void testUpdateCustomer() {
        Long customerId = 1L;

        Customer existingCustomer = new Customer();
        existingCustomer.setCustomerId(customerId);
        existingCustomer.setFirstName("John");
        existingCustomer.setLastName("Doe");

        CustomerDTO updatedCustomerDTO = new CustomerDTO();
        updatedCustomerDTO.setCustomerId(customerId);
        updatedCustomerDTO.setFirstName("Jane");
        updatedCustomerDTO.setLastName("Smith");

        Customer updatedCustomer = new Customer();
        updatedCustomer.setCustomerId(customerId);
        updatedCustomer.setFirstName("Jane");
        updatedCustomer.setLastName("Smith");

        when(customerRepository.findById(customerId)).thenReturn(Optional.of(existingCustomer));
        when(customerRepository.save(updatedCustomer)).thenReturn(updatedCustomer);
        when(customerMapper.toDTO(updatedCustomer)).thenReturn(updatedCustomerDTO);

        CustomerDTO result = customerService.updateCustomer(customerId, updatedCustomerDTO);

        assertEquals(updatedCustomerDTO, result);
    }

    @Test
    public void testDeleteCustomer() {
        Long customerId = 1L;

        customerService.deleteCustomer(customerId);

        verify(customerRepository, times(1)).deleteById(customerId);
    }
}
