package com.project.cakmazon.services;

import com.project.cakmazon.dto.CustomerDTO;
import com.project.cakmazon.dto.OrderDTO;
import com.project.cakmazon.mapper.OrderMapper;
import com.project.cakmazon.model.Customer;
import com.project.cakmazon.model.Order;
import com.project.cakmazon.model.OrderItem;
import com.project.cakmazon.repo.OrderRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class OrderServiceTest {

    @Mock
    private OrderRepository orderRepository;

    @Mock
    private OrderMapper orderMapper;

    @Mock
    private CustomerService customerService;

    @Mock
    private CustomerMapper customerMapper;

    @InjectMocks
    private OrderService orderService;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testGetAllOrders() {
      
        Order order1 = new Order();
        order1.setId(1L);
        Order order2 = new Order();
        order2.setId(2L);

        OrderDTO orderDTO1 = new OrderDTO();
        orderDTO1.setId(1L);
        OrderDTO orderDTO2 = new OrderDTO();
        orderDTO2.setId(2L);

        when(orderRepository.findAll()).thenReturn(Arrays.asList(order1, order2));
        when(orderMapper.toDTO(order1)).thenReturn(orderDTO1);
        when(orderMapper.toDTO(order2)).thenReturn(orderDTO2);

        List<OrderDTO> result = orderService.getAllOrders();

        assertEquals(2, result.size());
        assertEquals(orderDTO1, result.get(0));
        assertEquals(orderDTO2, result.get(1));
    }

    @Test
    public void testGetOrderById() {
        Long orderId = 1L;

        Order order = new Order();
        order.setId(orderId);

        OrderDTO orderDTO = new OrderDTO();
        orderDTO.setId(orderId);

        when(orderRepository.findById(orderId)).thenReturn(Optional.of(order));
        when(orderMapper.toDTO(order)).thenReturn(orderDTO);

        OrderDTO result = orderService.getOrderById(orderId);

        assertEquals(orderDTO, result);
    }

    @Test
    public void testGetOrdersByCustomerId() {
        Long customerId = 1L;

        CustomerDTO customerDTO = new CustomerDTO();
        customerDTO.setCustomerId(customerId);

        Order order1 = new Order();
        order1.setId(1L);
        Order order2 = new Order();
        order2.setId(2L);

        OrderDTO orderDTO1 = new OrderDTO();
        orderDTO1.setId(1L);
        OrderDTO orderDTO2 = new OrderDTO();
        orderDTO2.setId(2L);

        when(customerService.getCustomerById(customerId)).thenReturn(Optional.of(customerDTO));
        when(orderRepository.findByCustomer_CustomerId(customerDTO)).thenReturn(Arrays.asList(order1, order2));
        when(orderMapper.toDTO(order1)).thenReturn(orderDTO1);
        when(orderMapper.toDTO(order2)).thenReturn(orderDTO2);

        List<OrderDTO> result = orderService.getOrdersByCustomerId(customerId);

        assertEquals(2, result.size());
        assertEquals(orderDTO1, result.get(0));
        assertEquals(orderDTO2, result.get(1));
    }

    @Test
    public void testPlaceOrder() {
        Long customerId = 1L;

        CustomerDTO customerDTO = new CustomerDTO();
        customerDTO.setCustomerId(customerId);

        OrderItem orderItem = new OrderItem();
        orderItem.setQuantity(2);

        Order order = new Order();
        order.setId(1L);

        when(customerService.getCustomerById(customerId)).thenReturn(Optional.of(customerDTO));
        when(orderRepository.save(order)).thenReturn(order);

        orderService.placeOrder(customerId, Collections.singletonList(orderItem));

        verify(orderRepository, times(1)).save(order);
    }

    @Test
    public void testSaveOrder() {
       
        Order order = new Order();
        order.setId(1L);

        when(orderRepository.save(order)).thenReturn(order);

        Order result = orderService.saveOrder(order);

        assertEquals(order, result);
    }

    @Test
    public void testDeleteOrder() {
        Long orderId = 1L;

        orderService.deleteOrder(orderId);

        verify(orderRepository, times(1)).deleteById(orderId);
    }

    @Test
    public void testGetOrdersInDateRange() {
        LocalDate startDate = LocalDate.now().minusDays(7);
        LocalDate endDate = LocalDate.now();

        Order order1 = new Order();
        order1.setId(1L);
        Order order2 = new Order();
        order2.setId(2L);

        OrderDTO orderDTO1 = new OrderDTO();
        orderDTO1.setId(1L);
        OrderDTO orderDTO2 = new OrderDTO();
        orderDTO2.setId(2L);

        when(orderRepository.findByOrderDateBetween(
                startDate.atStartOfDay(),
                endDate.atStartOfDay().plusHours(23).plusMinutes(59).plusSeconds(59)
        )).thenReturn(Arrays.asList(order1, order2));
        when(orderMapper.toDTOList(Arrays.asList(order1, order2))).thenReturn(Arrays.asList(orderDTO1, orderDTO2));

        List<OrderDTO> result = orderService.getOrdersInDateRange(startDate, endDate);

        assertEquals(2, result.size());
        assertEquals(orderDTO1, result.get(0));
        assertEquals(orderDTO2, result.get(1));
    }

    @Test
    public void testUpdateOrderStatus() {
        Long orderId = 1L;
        String newStatus = "SHIPPED";

        Order order = new Order();
        order.setId(orderId);

        when(orderRepository.findById(orderId)).thenReturn(Optional.of(order));

        orderService.updateOrderStatus(orderId, newStatus);

        assertEquals(newStatus, order.getStatus());
        verify(orderRepository, times(1)).save(order);
    }

    @Test
    public void testCountOrders() {
        when(orderRepository.count()).thenReturn(5L);

        long result = orderService.countOrders();

        assertEquals(5L, result);
    }
}
