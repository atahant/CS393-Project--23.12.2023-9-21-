package com.project.cakmazon;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CakmazonApplicationTests {

    @Test
    void contextLoads() {
        // Your test logic here
    }
}