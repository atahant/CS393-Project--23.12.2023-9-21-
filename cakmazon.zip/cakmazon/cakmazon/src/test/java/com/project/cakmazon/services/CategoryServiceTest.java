package com.project.cakmazon.services;

import com.project.cakmazon.dto.CategoryDTO;
import com.project.cakmazon.dto.ProductDTO;
import com.project.cakmazon.mapper.ProductMapper;
import com.project.cakmazon.model.Category;
import com.project.cakmazon.model.Product;
import com.project.cakmazon.repo.CategoryRepository;
import com.project.cakmazon.repo.ProductRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class CategoryServiceTest {

    @Mock
    private CategoryRepository categoryRepository;

    @Mock
    private ProductRepository productRepository;

    @Mock
    private ProductMapper productMapper;

    @InjectMocks
    private CategoryService categoryService;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testGetAllCategories() {
        
        Category category1 = new Category();
        category1.setId(1L);
        Category category2 = new Category();
        category2.setId(2L);

        
        CategoryDTO categoryDTO1 = new CategoryDTO();
        categoryDTO1.setCategoryId(1L);
        CategoryDTO categoryDTO2 = new CategoryDTO();
        categoryDTO2.setCategoryId(2L);

        when(categoryRepository.findAll()).thenReturn(Arrays.asList(category1, category2));
        when(categoryService.convertToDto(category1)).thenReturn(categoryDTO1);
        when(categoryService.convertToDto(category2)).thenReturn(categoryDTO2);

        List<CategoryDTO> result = categoryService.getAllCategories();

        assertEquals(2, result.size());
        assertEquals(categoryDTO1, result.get(0));
        assertEquals(categoryDTO2, result.get(1));
    }

    @Test
    public void testGetCategoryById() {
        Long categoryId = 1L;

        
        Category category = new Category();
        category.setId(categoryId);

       
        CategoryDTO categoryDTO = new CategoryDTO();
        categoryDTO.setCategoryId(categoryId);

        when(categoryRepository.findById(categoryId)).thenReturn(Optional.of(category));
        when(categoryService.convertToDto(category)).thenReturn(categoryDTO);

        CategoryDTO result = categoryService.getCategoryById(categoryId);

        assertEquals(categoryDTO, result);
    }

    @Test
    public void testSaveCategory() {
        
        CategoryDTO categoryDTO = new CategoryDTO();
        categoryDTO.setCategoryId(1L);

        
        Category category = new Category();
        category.setId(1L);

        when(categoryService.convertToEntity(categoryDTO)).thenReturn(category);
        when(categoryRepository.save(category)).thenReturn(category);
        when(categoryService.convertToDto(category)).thenReturn(categoryDTO);

        CategoryDTO result = categoryService.saveCategory(categoryDTO);

        assertEquals(categoryDTO, result);
    }

    @Test
    public void testDeleteCategory() {
        Long categoryId = 1L;

        categoryService.deleteCategory(categoryId);

        verify(categoryRepository, times(1)).deleteById(categoryId);
    }

    @Test
    public void testGetProductsByCategoryId() {
        Long categoryId = 1L;

        
        Product product1 = new Product();
        product1.setProductId(1L);
        Product product2 = new Product();
        product2.setProductId(2L);

        
        ProductDTO productDTO1 = new ProductDTO();
        productDTO1.setProductId(1L);
        ProductDTO productDTO2 = new ProductDTO();
        productDTO2.setProductId(2L);

        when(productRepository.findByCategoryId(categoryId)).thenReturn(Arrays.asList(product1, product2));
        when(productMapper.toDTOList(Arrays.asList(product1, product2))).thenReturn(Arrays.asList(productDTO1, productDTO2));

        List<ProductDTO> result = categoryService.getProductsByCategoryId(categoryId);

        assertEquals(2, result.size());
        assertEquals(productDTO1, result.get(0));
        assertEquals(productDTO2, result.get(1));
    }

    @Test
    public void testAddProductToCategory() {
        Long categoryId = 1L;

        
        Category category = new Category();
        category.setId(categoryId);

      
        ProductDTO productDTO = new ProductDTO();
        productDTO.setProductId(1L);

        Product product = new Product();
        product.setProductId(1L);

        when(categoryRepository.findById(categoryId)).thenReturn(Optional.of(category));
        when(productMapper.toEntity(productDTO)).thenReturn(product);
        when(categoryRepository.save(category)).thenReturn(category);

        Category result = categoryService.addProductToCategory(categoryId, productDTO);

        assertNotNull(result);
        assertEquals(category, result);
    }

    @Test
    public void testRemoveProductFromCategory() {
        Long categoryId = 1L;
        Long productId = 1L;

        Category category = new Category();
        category.setId(categoryId);

        Product product = new Product();
        product.setProductId(productId);

        category.getProducts().add(product);

        when(categoryRepository.findById(categoryId)).thenReturn(Optional.of(category));
        when(categoryRepository.save(category)).thenReturn(category);

        categoryService.removeProductFromCategory(categoryId, productId);

        assertTrue(category.getProducts().isEmpty());
    }
}
