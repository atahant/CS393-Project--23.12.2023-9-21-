package com.project.cakmazon.services;

import com.project.cakmazon.dto.CartItemDTO;
import com.project.cakmazon.dto.ProductDTO;
import com.project.cakmazon.mapper.ProductMapper;
import com.project.cakmazon.model.CartItem;
import com.project.cakmazon.model.Category;
import com.project.cakmazon.model.Product;
import com.project.cakmazon.repo.CartItemRepository;
import com.project.cakmazon.repo.CategoryRepository;
import com.project.cakmazon.repo.ProductRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class ProductServiceTest {

    @Mock
    private ProductRepository productRepository;

    @Mock
    private CategoryRepository categoryRepository;

    @Mock
    private CartItemRepository cartItemRepository;

    @Mock
    private ProductMapper productMapper;

    @InjectMocks
    private ProductService productService;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testGetAllProductDTOs() {
        
        Product product1 = new Product();
        product1.setProductId(1L);
        Product product2 = new Product();
        product2.setProductId(2L);

        ProductDTO productDTO1 = new ProductDTO();
        productDTO1.setProductId(1L);
        ProductDTO productDTO2 = new ProductDTO();
        productDTO2.setProductId(2L);

        when(productRepository.findAll()).thenReturn(Arrays.asList(product1, product2));
        when(productMapper.toDTO(product1)).thenReturn(productDTO1);
        when(productMapper.toDTO(product2)).thenReturn(productDTO2);

        List<ProductDTO> result = productService.getAllProductDTOs();

        assertEquals(2, result.size());
        assertEquals(productDTO1, result.get(0));
        assertEquals(productDTO2, result.get(1));
    }

    @Test
    public void testGetProductDTOById() {
        Long productId = 1L;

        Product product = new Product();
        product.setProductId(productId);

        ProductDTO productDTO = new ProductDTO();
        productDTO.setProductId(productId);

        when(productRepository.findById(productId)).thenReturn(Optional.of(product));
        when(productMapper.toDTO(product)).thenReturn(productDTO);

        ProductDTO result = productService.getProductDTOById(productId);

        assertEquals(productDTO, result);
    }

    @Test
    public void testSaveProductDTO() {
        
        ProductDTO productDTO = new ProductDTO();
        productDTO.setProductId(1L);
        productDTO.setName("Test Product");

        Product product = new Product();
        product.setProductId(1L);
        product.setName("Test Product");

        when(productMapper.toEntity(productDTO)).thenReturn(product);
        when(productRepository.save(product)).thenReturn(product);
        when(productMapper.toDTO(product)).thenReturn(productDTO);

        ProductDTO result = productService.saveProductDTO(productDTO);

        assertEquals(productDTO, result);
    }

    @Test
    public void testDeleteProduct() {
        Long productId = 1L;

        productService.deleteProduct(productId);

        verify(productRepository, times(1)).deleteById(productId);
    }

    @Test
    public void testGetProductsByCategoryDTO() {
        Long categoryId = 1L;

        Product product1 = new Product();
        product1.setProductId(1L);
        Product product2 = new Product();
        product2.setProductId(2L);

        ProductDTO productDTO1 = new ProductDTO();
        productDTO1.setProductId(1L);
        ProductDTO productDTO2 = new ProductDTO();
        productDTO2.setProductId(2L);

        when(productRepository.findByCategoryId(categoryId)).thenReturn(Arrays.asList(product1, product2));
        when(productMapper.toDTO(product1)).thenReturn(productDTO1);
        when(productMapper.toDTO(product2)).thenReturn(productDTO2);

        List<ProductDTO> result = productService.getProductsByCategoryDTO(categoryId);

        assertEquals(2, result.size());
        assertEquals(productDTO1, result.get(0));
        assertEquals(productDTO2, result.get(1));
    }

    @Test
    public void testGetProductsInStockDTO() {
        
        Product product1 = new Product();
        product1.setProductId(1L);
        product1.setStockQuantity(5);

        Product product2 = new Product();
        product2.setProductId(2L);
        product2.setStockQuantity(0);

        ProductDTO productDTO1 = new ProductDTO();
        productDTO1.setProductId(1L);
        productDTO1.setStockQuantity(5);

        when(productRepository.findByStockQuantityGreaterThan(0)).thenReturn(Arrays.asList(product1));
        when(productMapper.toDTO(product1)).thenReturn(productDTO1);

        List<ProductDTO> result = productService.getProductsInStockDTO();

        assertEquals(1, result.size());
        assertEquals(productDTO1, result.get(0));
    }

    @Test
    public void testUpdateProductInformation() {
        Long productId = 1L;

        Product existingProduct = new Product();
        existingProduct.setProductId(productId);
        existingProduct.setName("Old Product");

        ProductDTO updatedProductDTO = new ProductDTO();
        updatedProductDTO.setName("New Product");

        when(productRepository.findById(productId)).thenReturn(Optional.of(existingProduct));

        productService.updateProductInformation(productId, updatedProductDTO);

        assertEquals(updatedProductDTO.getName(), existingProduct.getName());
        verify(productRepository, times(1)).save(existingProduct);
    }

    @Test
    public void testIsProductAvailable() {
        Long productId = 1L;
        int quantity = 3;

        Product product = new Product();
        product.setProductId(productId);
        product.setStockQuantity(5);

        when(productRepository.findById(productId)).thenReturn(Optional.of(product));

        boolean result = productService.isProductAvailable(productId, quantity);

        assertTrue(result);
    }

    @Test
    public void testAddToCart() {
        Long productId = 1L;

        Product product = new Product();
        product.setProductId(productId);
        product.setName("Test Product");

        CartItemDTO cartItemDTO = new CartItemDTO();
        cartItemDTO.setCartItemId(1L);
        cartItemDTO.setQuantity(2);

        CartItem existingCartItem = new CartItem();
        existingCartItem.setId(1L);
        existingCartItem.setProduct(product);
        existingCartItem.setQuantity(3);

        when(productRepository.findById(productId)).thenReturn(Optional.of(product));
        when(cartItemRepository.findAll()).thenReturn(Arrays.asList(existingCartItem));
        when(productService.convertCartItemToEntity(cartItemDTO)).thenReturn(existingCartItem);
        when(cartItemRepository.save(existingCartItem)).thenReturn(existingCartItem);

        productService.addToCart(productId, cartItemDTO);

        assertEquals(5, existingCartItem.getQuantity());
        verify(cartItemRepository, times(1)).save(existingCartItem);
    }

    @Test
    public void testViewCart() {
      
        CartItem cartItem1 = new CartItem();
        cartItem1.setId(1L);
        cartItem1.setQuantity(2);

        CartItem cartItem2 = new CartItem();
        cartItem2.setId(2L);
        cartItem2.setQuantity(3);

        CartItemDTO cartItemDTO1 = new CartItemDTO();
        cartItemDTO1.setCartItemId(1L);
        cartItemDTO1.setQuantity(2);

        CartItemDTO cartItemDTO2 = new CartItemDTO();
        cartItemDTO2.setCartItemId(2L);
        cartItemDTO2.setQuantity(3);

        when(cartItemRepository.findAll()).thenReturn(Arrays.asList(cartItem1, cartItem2));
        when(productService.convertCartItemToDto(cartItem1)).thenReturn(cartItemDTO1);
        when(productService.convertCartItemToDto(cartItem2)).thenReturn(cartItemDTO2);

        List<CartItemDTO> result = productService.viewCart();

        assertEquals(2, result.size());
        assertEquals(cartItemDTO1, result.get(0));
        assertEquals(cartItemDTO2, result.get(1));
    }
}
