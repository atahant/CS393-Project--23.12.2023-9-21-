package com.project.cakmazon.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.project.cakmazon.dto.CartItemDTO;
import com.project.cakmazon.mapper.CartItemMapper;
import com.project.cakmazon.model.CartItem;
import com.project.cakmazon.services.CartItemService;

import java.util.List;

@RestController
@RequestMapping("/cart-items")
public class CartItemController {

    @Autowired
    private CartItemService cartItemService;

    @Autowired
    private CartItemMapper cartItemMapper;
    
    
    @GetMapping
    public List<CartItemDTO> getAllCartItems() {
        List<CartItemDTO> cartItems = cartItemService.getAllCartItems();
        return cartItems;
    }

    @GetMapping("/{cartItemId}")
    public CartItemDTO getCartItemById(@PathVariable Long cartItemId) {
        CartItemDTO cartItem = cartItemService.getCartItemById(cartItemId)
                .orElseThrow(() -> new RuntimeException("CartItem not found with id: " + cartItemId));
        return cartItem;
    }

    @PostMapping
    public void saveCartItem(@RequestBody CartItemDTO cartItemDTO) {
        cartItemService.saveCartItem(cartItemDTO);
        return;
    }

    @PutMapping("/{cartItemId}")
    public void updateCartItem(@PathVariable Long cartItemId, @RequestBody CartItemDTO updatedCartItemDTO) {
        cartItemService.updateCartItem(cartItemId, updatedCartItemDTO);
    }

    @DeleteMapping("/{cartItemId}")
    public void deleteCartItem(@PathVariable Long cartItemId) {
        cartItemService.deleteCartItem(cartItemId);
    }
}

