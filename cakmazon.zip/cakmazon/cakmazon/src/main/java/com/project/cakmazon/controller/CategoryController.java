package com.project.cakmazon.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.project.cakmazon.dto.CategoryDTO;
import com.project.cakmazon.dto.ProductDTO;
import com.project.cakmazon.model.Category;
import com.project.cakmazon.model.Product;
import com.project.cakmazon.services.CategoryService;

import io.swagger.v3.oas.annotations.parameters.RequestBody;

import java.util.List;

@RestController
@RequestMapping("/categories")
public class CategoryController {

    @Autowired
    private CategoryService categoryService;

    @GetMapping
    public List<CategoryDTO> getAllCategories() {
        return categoryService.getAllCategories();
    }
    
    @GetMapping("/{categoryId}")
    public CategoryDTO getCategoryById(@PathVariable Long categoryId) {
        return categoryService.getCategoryById(categoryId);
    }

    @PostMapping
    public CategoryDTO saveCategory(@RequestBody CategoryDTO categoryDTO) {
        return categoryService.saveCategory(categoryDTO);
    }

    @DeleteMapping("/{categoryId}")
    public void deleteCategory(@PathVariable Long categoryId) {
        categoryService.deleteCategory(categoryId);
    }

    @GetMapping("/{categoryId}/products")
    public List<ProductDTO> getProductsByCategoryId(@PathVariable Long categoryId) {
        return categoryService.getProductsByCategoryId(categoryId);
    }

    @PostMapping("/{categoryId}/products")
    public void addProductToCategory(@PathVariable Long categoryId, @RequestBody ProductDTO productDTO) {
        categoryService.addProductToCategory(categoryId, productDTO);
    }

    @DeleteMapping("/{categoryId}/products/{productId}")
    public void removeProductFromCategory(@PathVariable Long categoryId, @PathVariable Long productId) {
        categoryService.removeProductFromCategory(categoryId, productId);
    }
}
