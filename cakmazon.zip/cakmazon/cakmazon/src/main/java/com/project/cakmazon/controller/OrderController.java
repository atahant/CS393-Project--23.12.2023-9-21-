package com.project.cakmazon.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.*;

import com.project.cakmazon.dto.OrderDTO;
import com.project.cakmazon.dto.OrderItemDTO;
import com.project.cakmazon.mapper.OrderItemMapper;
import com.project.cakmazon.model.Order;
import com.project.cakmazon.model.OrderItem;
import com.project.cakmazon.model.Product;
import com.project.cakmazon.services.CartItemService;
import com.project.cakmazon.services.OrderService;
import com.project.cakmazon.services.ProductService;

import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("/orders")
public class OrderController {

	@Autowired
	private OrderService orderService;

	@Autowired
	private CartItemService cartItemService;

	@Autowired
	private ProductService productService;
	
	@Autowired
	private OrderItemMapper orderItemMapper;

	@GetMapping
	public List<OrderDTO> getAllOrders() {
		return orderService.getAllOrders();
	}

	@GetMapping("/{orderId}")
	public OrderDTO getOrderById(@PathVariable Long orderId) {
		return orderService.getOrderById(orderId);
	}

	@PostMapping("/placeOrder")
	public void placeOrder(@RequestBody PlaceOrderRequest placeOrderRequest) {
		orderService.placeOrder(placeOrderRequest.getCustomerId(), orderItemMapper.toEntityList(placeOrderRequest.getOrderItems()));
	}

	@GetMapping("/customer/{customerId}")
	public List<OrderDTO> getOrdersByCustomerId(@PathVariable Long customerId) {
		return orderService.getOrdersByCustomerId(customerId);
	}

	@PutMapping("/{orderId}/updateStatus")
    public void updateOrderStatus(@PathVariable Long orderId, @RequestParam String newStatus) {
        orderService.updateOrderStatus(orderId, newStatus);
    }
	
	static class PlaceOrderRequest {
        private Long customerId;
        private List<OrderItemDTO> orderItems;
		public Long getCustomerId() {
			return customerId;
		}
		public void setCustomerId(Long customerId) {
			this.customerId = customerId;
		}
		public List<OrderItemDTO> getOrderItems() {
			return orderItems;
		}
		public void setOrderItems(List<OrderItemDTO> orderItems) {
			this.orderItems = orderItems;
		}

    }
	
	@DeleteMapping("/{orderId}")
	public void cancelOrder(@PathVariable Long orderId) {
		orderService.deleteOrder(orderId);
	}

	@GetMapping("/date-range")
	public List<OrderDTO> getOrdersInDateRange(
			@RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate startDate,
			@RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate endDate) {
		return orderService.getOrdersInDateRange(startDate, endDate);
	}

	

}
