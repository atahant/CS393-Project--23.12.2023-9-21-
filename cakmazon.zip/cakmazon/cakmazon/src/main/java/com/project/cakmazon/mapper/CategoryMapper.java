package com.project.cakmazon.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import com.project.cakmazon.dto.CategoryDTO;
import com.project.cakmazon.model.Category;

@Mapper
public interface CategoryMapper {
    CategoryMapper INSTANCE = Mappers.getMapper(CategoryMapper.class);

    CategoryDTO toDTO(Category category);

    Category toEntity(CategoryDTO categoryDTO);
}
