package com.project.cakmazon.mapper;

import java.util.List;

import org.mapstruct.Mapper;

import com.project.cakmazon.dto.CartItemDTO;
import com.project.cakmazon.model.CartItem;

@Mapper(componentModel = "spring")
public interface CartItemMapper {

    
    CartItemDTO toDTO(CartItem cartItem);

    CartItem toEntity(CartItemDTO cartItemDTO);
    
    List<CartItemDTO> toDTOList(List<CartItem> cartItems);
}