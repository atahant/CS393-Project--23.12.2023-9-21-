package com.project.cakmazon;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.project.cakmazon.dto.ProductDTO;
import com.project.cakmazon.mapper.ProductMapper;
import com.project.cakmazon.model.CartItem;
import com.project.cakmazon.model.Category;
import com.project.cakmazon.model.Customer;
import com.project.cakmazon.model.Order;
import com.project.cakmazon.model.OrderItem;
import com.project.cakmazon.model.Product;
import com.project.cakmazon.repo.CartItemRepository;
import com.project.cakmazon.repo.CategoryRepository;
import com.project.cakmazon.repo.CustomerRepository;
import com.project.cakmazon.services.OrderService;
import com.project.cakmazon.services.ProductService;

import jakarta.annotation.PostConstruct;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;

@Component
public class DatabaseInitializer {

    @Autowired
    private CartItemRepository cartItemRepository;

    @Autowired
    private CustomerRepository customerRepository;

    @Autowired
    private ProductService productService;

    @Autowired
    private CategoryRepository categoryRepository;

    @Autowired
    private OrderService orderService;
    
    @Autowired
    private ProductMapper productMapper;

    @PostConstruct
    public void initializeData() {
        initializeEntities();
    }

    private void initializeEntities() {
        if (cartItemRepository.count() == 0) {
            initializeCartItems();
        }

        if (customerRepository.count() == 0) {
            initializeCustomers();
        }

        if (categoryRepository.count() == 0) {
            initializeCategoriesAndProducts();
        }

        if (orderService.countOrders() == 0) {
            initializeOrders();
        }
    }

    private void initializeCartItems() {
        ProductDTO product1 = productService.getProductDTOById(1L);
        ProductDTO product2 = productService.getProductDTOById(2L);

        if (product1 != null && product2 != null) {
          
            CartItem cartItem1 = new CartItem();
            cartItem1.setProduct(productMapper.toEntity(product1));
            cartItem1.setQuantity(2);

            CartItem cartItem2 = new CartItem();
            cartItem2.setProduct(productMapper.toEntity(product2));
            cartItem2.setQuantity(1);

            cartItemRepository.saveAll(Arrays.asList(cartItem1, cartItem2));
        }
    }

    private void initializeCustomers() {
        Customer customer1 = new Customer();
        customer1.setFirstName("John");
        customer1.setLastName("Doe");
        customer1.setEmail("john.doe@example.com");
        customer1.setAddress("123 Main Street");

        Customer customer2 = new Customer();
        customer2.setFirstName("Jane");
        customer2.setLastName("Smith");
        customer2.setEmail("jane.smith@example.com");
        customer2.setAddress("456 Oak Avenue");

        customerRepository.saveAll(Arrays.asList(customer1, customer2));
    }

    private void initializeCategoriesAndProducts() {
        Category electronicsCategory = new Category();
        electronicsCategory.setName("Electronics");

        Category clothingCategory = new Category();
        clothingCategory.setName("Clothing");

        Product laptop = new Product();
        laptop.setName("Laptop");
        laptop.setPrice(999.99);
        laptop.setDescription("High-performance laptop");
        laptop.setStockQuantity(10);
        laptop.setCategory(electronicsCategory);

        Product shirt = new Product();
        shirt.setName("Shirt");
        shirt.setPrice(19.99);
        shirt.setDescription("Casual shirt");
        shirt.setStockQuantity(50);
        shirt.setCategory(clothingCategory);

        electronicsCategory.getProducts().add(laptop);
        clothingCategory.getProducts().add(shirt);

        categoryRepository.saveAll(Arrays.asList(electronicsCategory, clothingCategory));
    }

    private void initializeOrders() {
        Customer customer1 = customerRepository.findById(1L).orElse(null);
        Customer customer2 = customerRepository.findById(2L).orElse(null);

        ProductDTO product1 = productService.getProductDTOById(1L);
        ProductDTO product2 = productService.getProductDTOById(2L);

        if (customer1 != null && customer2 != null && product1 != null && product2 != null) {
            Order order1 = new Order();
            order1.setCustomer(customer1);
            order1.setOrderItems(Arrays.asList(
                    createOrderItem(order1, productMapper.toEntity(product1), 2),
                    createOrderItem(order1, productMapper.toEntity(product2), 1)
            ));
            order1.setTotalAmount(calculateTotalAmount(order1.getOrderItems()));
            order1.setShippingAddress("123 Main St, Cityville");
            order1.setPaymentMethod("Credit Card");
            order1.setStatus("Pending");
            order1.setOrderDate(LocalDateTime.now());
            
            Order order2 = new Order();
            order2.setCustomer(customer2);
            order2.setOrderItems(Arrays.asList(
                    createOrderItem(order2, productMapper.toEntity(product1), 1),
                    createOrderItem(order2, productMapper.toEntity(product2), 3)
            ));
            order2.setTotalAmount(calculateTotalAmount(order2.getOrderItems()));
            order2.setShippingAddress("456 Oak St, Townsville");
            order2.setPaymentMethod("PayPal");
            order2.setStatus("Shipped");
            order2.setOrderDate(LocalDateTime.now());
         
            orderService.saveOrder(order1);
            orderService.saveOrder(order2);
        }
    }

    private OrderItem createOrderItem(Order order, Product product, int quantity) {
        OrderItem orderItem = new OrderItem();
        orderItem.setOrder(order);  
        orderItem.setProduct(product);
        orderItem.setQuantity(quantity);
        return orderItem;
    }

    private double calculateTotalAmount(List<OrderItem> orderItems) {
        return orderItems.stream()
                .mapToDouble(orderItem -> orderItem.getProduct().getPrice() * orderItem.getQuantity())
                .sum();
    }
}
