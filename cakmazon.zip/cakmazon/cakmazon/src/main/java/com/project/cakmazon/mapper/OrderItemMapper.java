package com.project.cakmazon.mapper;
import java.util.List;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import com.project.cakmazon.dto.OrderItemDTO;
import com.project.cakmazon.model.OrderItem;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface OrderItemMapper {
    OrderItemMapper INSTANCE = Mappers.getMapper(OrderItemMapper.class);

    @Mapping(source = "order.id", target = "orderId")
    OrderItemDTO toDTO(OrderItem orderItem);

    OrderItem toEntity(OrderItemDTO orderItemDTO);
    
    List<OrderItemDTO> toDTOList(List<OrderItem> orderItems);
    
    List<OrderItem> toEntityList(List<OrderItemDTO> orderItemDTOs);
}
