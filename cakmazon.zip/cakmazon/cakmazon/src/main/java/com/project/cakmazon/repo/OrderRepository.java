package com.project.cakmazon.repo;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.project.cakmazon.dto.CustomerDTO;
import com.project.cakmazon.model.Order;

public interface OrderRepository extends JpaRepository<Order, Long> {
	List<Order> findByCustomer_CustomerId(Long customerId);

    List<Order> findByOrderDateBetween(LocalDateTime startDate, LocalDateTime endDate);

    List<Order> findByStatus(String status);

	List<Order> findByCustomer_CustomerId(Optional<CustomerDTO> customer);
}
