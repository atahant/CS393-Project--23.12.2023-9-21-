package com.project.cakmazon.controller;

import com.project.cakmazon.dto.ProductDTO;
import com.project.cakmazon.services.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import com.project.cakmazon.dto.CartItemDTO;

import java.util.List;

@RestController
@RequestMapping("/products")
public class ProductController {

    @Autowired
    private ProductService productService;

    @GetMapping
    public List<ProductDTO> getAllProductDTOs() {
        return productService.getAllProductDTOs();
    }

    @GetMapping("/{productId}")
    public ProductDTO getProductDTOById(@PathVariable Long productId) {
        return productService.getProductDTOById(productId);
    }

    @PostMapping
    public ProductDTO saveProductDTO(@RequestBody ProductDTO productDTO) {
        return productService.saveProductDTO(productDTO);
    }

    @DeleteMapping("/{productId}")
    public void deleteProduct(@PathVariable Long productId) {
        productService.deleteProduct(productId);
    }

    @GetMapping("/category/{categoryId}")
    public List<ProductDTO> getProductsByCategoryDTO(@PathVariable Long categoryId) {
        return productService.getProductsByCategoryDTO(categoryId);
    }

    @GetMapping("/instock")
    public List<ProductDTO> getProductsInStockDTO() {
        return productService.getProductsInStockDTO();
    }

    @PutMapping("/{productId}")
    public void updateProductInformation(@PathVariable Long productId, @RequestBody ProductDTO updatedProductInfo) {
        productService.updateProductInformation(productId, productService.convertProductToEntity(updatedProductInfo));
    }

    @GetMapping("/{productId}/availability/{quantity}")
    public boolean isProductAvailable(@PathVariable Long productId, @PathVariable int quantity) {
        return productService.isProductAvailable(productId, quantity);
    }

    @PostMapping("/{productId}/add-to-cart")
    public void addToCart(@PathVariable Long productId, @RequestParam CartItemDTO cartItemDTO) {
        productService.addToCart(productId, cartItemDTO);
    }

    @GetMapping("/cart")
    public List<CartItemDTO> viewCart() {
        return productService.viewCart();
    }

}


