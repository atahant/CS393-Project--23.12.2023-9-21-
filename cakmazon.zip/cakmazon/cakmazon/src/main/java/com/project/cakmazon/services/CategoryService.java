package com.project.cakmazon.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.cakmazon.dto.CategoryDTO;
import com.project.cakmazon.dto.ProductDTO;
import com.project.cakmazon.mapper.ProductMapper;
import com.project.cakmazon.model.Category;
import com.project.cakmazon.model.Product;
import com.project.cakmazon.repo.CategoryRepository;
import com.project.cakmazon.repo.ProductRepository;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class CategoryService {

    @Autowired
    private CategoryRepository categoryRepository;
    
    @Autowired
    private ProductRepository productRepository;
    
    @Autowired
    private ProductMapper productMapper;

    public List<CategoryDTO> getAllCategories() {
        List<Category> categories = categoryRepository.findAll();

        
        return categories.stream()
                .map(this::convertToDto)
                .collect(Collectors.toList());
    }
    public CategoryDTO getCategoryById(Long categoryId) {
        Category category = categoryRepository.findById(categoryId)
                .orElseThrow(() -> new RuntimeException("Category not found with id: " + categoryId));

        
        return convertToDto(category);
    }

    public CategoryDTO saveCategory(CategoryDTO categoryDTO) {
        Category category = convertToEntity(categoryDTO);

        Category savedCategory = categoryRepository.save(category);

        return convertToDto(savedCategory);
    }


    public void deleteCategory(Long id) {
        categoryRepository.deleteById(id);
    }
    public List<ProductDTO> getProductsByCategoryId(Long categoryId) {
        List<Product> products = productRepository.findByCategoryId(categoryId);

        List<ProductDTO> productDTOs = productMapper.toDTOList(products);

        return productDTOs;
    }
    public Category addProductToCategory(Long categoryId, ProductDTO productDTO) {
        Category category = categoryRepository.findById(categoryId)
                .orElseThrow(() -> new RuntimeException("Category not found with id: " + categoryId));
        Product product = productMapper.toEntity(productDTO);
        category.getProducts().add(product);
        return categoryRepository.save(category);
    }
    public void removeProductFromCategory(Long categoryId, Long productId) {
        Optional<Category> categoryOptional = categoryRepository.findById(categoryId);
        categoryOptional.ifPresent(category -> {
            category.getProducts().removeIf(product -> product.getProductId().equals(productId));
            categoryRepository.save(category);
        });
    }
    
    private Category convertToEntity(CategoryDTO categoryDTO) {
        Category category = new Category();
        category.setId(categoryDTO.getCategoryId());
        category.setName(categoryDTO.getName());
        
        return category;
    }

   
    private CategoryDTO convertToDto(Category category) {
        CategoryDTO categoryDTO = new CategoryDTO();
        categoryDTO.setCategoryId(category.getId());
        categoryDTO.setName(category.getName());
        
        return categoryDTO;
    }
}

