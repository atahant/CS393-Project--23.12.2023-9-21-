package com.project.cakmazon.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.cakmazon.dto.CustomerDTO;
import com.project.cakmazon.dto.OrderDTO;
import com.project.cakmazon.mapper.CustomerMapper;
import com.project.cakmazon.mapper.OrderMapper;
import com.project.cakmazon.model.Customer;
import com.project.cakmazon.model.Order;
import com.project.cakmazon.model.OrderItem;
import com.project.cakmazon.repo.OrderRepository;

import jakarta.transaction.Transactional;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class OrderService {

    @Autowired
    private OrderRepository orderRepository;
    
    @Autowired
    private OrderMapper orderMapper;
    
    @Autowired
    private CustomerService customerService;
    
    @Autowired
    private CustomerMapper customerMapper;

    public List<OrderDTO> getAllOrders() {
        List<Order> orders = orderRepository.findAll();
        return orders.stream()
                .map(orderMapper::toDTO)
                .collect(Collectors.toList());
    }

    public OrderDTO getOrderById(Long orderId) {
        Optional<Order> orderOptional = orderRepository.findById(orderId);
        return orderOptional.map(orderMapper::toDTO).orElse(null);
    }
    public List<OrderDTO> getOrdersByCustomerId(Long customerId) {
        Optional<CustomerDTO> customer = customerService.getCustomerById(customerId);
        if (customer != null) {
            List<Order> orders = orderRepository.findByCustomer_CustomerId(customer);
            return orders.stream()
                    .map(orderMapper::toDTO)
                    .collect(Collectors.toList());
        }
        return null;
    }
    @Transactional
    public void placeOrder(Long customerId, List<OrderItem> orderItems) {
        Optional<CustomerDTO> customer = customerService.getCustomerById(customerId);
        if (customer != null) {
            Order order = new Order();
            order.setCustomer(customerMapper.toEntityOp(customer));
            order.setOrderItems(orderItems);
            order.setOrderDate(LocalDateTime.now());
            order.setShippingAddress(customerMapper.toEntityOp(customer).getAddress());
            double totalAmount = orderItems.stream()
                    .mapToDouble(item -> item.getProduct().getPrice() * item.getQuantity())
                    .sum();
            order.setTotalAmount(totalAmount);
            orderRepository.save(order);
        }
    }

    public Order saveOrder(Order order) {
        return orderRepository.save(order);
    }

    public void deleteOrder(Long id) {
        orderRepository.deleteById(id);
    }
   

    public List<OrderDTO> getOrdersInDateRange(LocalDate startDate, LocalDate endDate) {
        List<Order> orders = orderRepository.findByOrderDateBetween(
                startDate.atStartOfDay(),
                endDate.atStartOfDay().plusHours(23).plusMinutes(59).plusSeconds(59)
        );
        return OrderMapper.INSTANCE.toDTOList(orders);
    }

    public void updateOrderStatus(Long orderId, String newStatus) {
        Order order = orderRepository.findById(orderId)
                .orElseThrow(() -> new RuntimeException("Order not found with id: " + orderId));

        order.setStatus(newStatus);

        orderRepository.save(order);
    }

    public long countOrders() {
        return orderRepository.count();
    }
}
