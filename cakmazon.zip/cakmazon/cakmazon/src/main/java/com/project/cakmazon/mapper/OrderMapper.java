package com.project.cakmazon.mapper;
import java.util.List;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import com.project.cakmazon.dto.OrderDTO;
import com.project.cakmazon.model.Order;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface OrderMapper {
    OrderMapper INSTANCE = Mappers.getMapper(OrderMapper.class);

    
    OrderDTO toDTO(Order order);

    Order toEntity(OrderDTO orderDTO);
    
    List<OrderDTO> toDTOList(List<Order> orders);
}
