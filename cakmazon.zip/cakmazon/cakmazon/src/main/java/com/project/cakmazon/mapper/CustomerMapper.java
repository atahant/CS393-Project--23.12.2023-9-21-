package com.project.cakmazon.mapper;
import java.util.List;
import java.util.Optional;

import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import com.project.cakmazon.dto.CustomerDTO;
import com.project.cakmazon.model.Customer;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface CustomerMapper {
    CustomerMapper INSTANCE = Mappers.getMapper(CustomerMapper.class);

    CustomerDTO toDTO(Customer customer);

    Customer toEntityOp(Optional<CustomerDTO> customer);
    
    List<CustomerDTO> toDTOList(List<Customer> customers);

	Customer toEntity(CustomerDTO customerDTO);
}
