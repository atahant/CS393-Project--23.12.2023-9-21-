package com.project.cakmazon.repo;
import org.springframework.data.jpa.repository.JpaRepository;

import com.project.cakmazon.dto.CartItemDTO;
import com.project.cakmazon.model.CartItem;

public interface CartItemRepository extends JpaRepository<CartItem, Long> {

	
    
}
