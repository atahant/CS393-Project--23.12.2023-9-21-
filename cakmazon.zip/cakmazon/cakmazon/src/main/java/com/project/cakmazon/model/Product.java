package com.project.cakmazon.model;


import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;

@Entity
public class Product {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long productId;
    private String name;
    private double price;
    private String description;
    private int stockQuantity;

    @OneToMany(mappedBy = "product", cascade = {CascadeType.PERSIST, CascadeType.MERGE})
    private List<OrderItem> orderItems;
    
    @ManyToOne
    @JoinColumn(name = "category_id")
    private Category category;
    
 public Long getProductId() {
     return productId;
 }

 public void setProductId(Long productId) {
     this.productId = productId;
 }

 public String getName() {
     return name;
 }

 public void setName(String name) {
     this.name = name;
 }

 public double getPrice() {
     return price;
 }

 public void setPrice(double price) {
     this.price = price;
 }

 public String getDescription() {
     return description;
 }

 public void setDescription(String description) {
     this.description = description;
 }

 public int getStockQuantity() {
     return stockQuantity;
 }

 public void setStockQuantity(int stockQuantity) {
     this.stockQuantity = stockQuantity;
 }

 public List<OrderItem> getOrderItems() {
     return orderItems;
 }

 public void setOrderItems(List<OrderItem> orderItems) {
     this.orderItems = orderItems;
 }

public Category getCategory() {
	return category;
}

public void setCategory(Category category) {
	this.category = category;
}



}
