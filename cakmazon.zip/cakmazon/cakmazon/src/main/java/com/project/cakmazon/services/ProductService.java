package com.project.cakmazon.services;

import com.project.cakmazon.dto.CartItemDTO;
import com.project.cakmazon.dto.ProductDTO;
import com.project.cakmazon.mapper.ProductMapper;
import com.project.cakmazon.model.CartItem;
import com.project.cakmazon.model.Category;
import com.project.cakmazon.model.Product;
import com.project.cakmazon.repo.CartItemRepository;
import com.project.cakmazon.repo.CategoryRepository;
import com.project.cakmazon.repo.ProductRepository;
import jakarta.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class ProductService {

    @Autowired
    private ProductRepository productRepository;

    @Autowired
    private CategoryRepository categoryRepository;

    @Autowired
    private ProductMapper productMapper;
    
    @Autowired
    private CartItemRepository cartItemRepository;

    public List<ProductDTO> getAllProductDTOs() {
        return productRepository.findAll().stream()
                .map(ProductMapper.INSTANCE::toDTO)
                .collect(Collectors.toList());
    }

    public ProductDTO getProductDTOById(Long productId) {
        return productRepository.findById(productId)
                .map(ProductMapper.INSTANCE::toDTO)
                .orElse(null);
    }

    public ProductDTO saveProductDTO(ProductDTO productDTO) {
        Product product = ProductMapper.INSTANCE.toEntity(productDTO);
        return ProductMapper.INSTANCE.toDTO(productRepository.save(product));
    }
    public void deleteProduct(Long productId) {
        productRepository.deleteById(productId);
    }

    public List<ProductDTO> getProductsByCategoryDTO(Long categoryId) {
        return productRepository.findByCategoryId(categoryId).stream()
                .map(ProductMapper.INSTANCE::toDTO)
                .collect(Collectors.toList());
    }

    public List<ProductDTO> getProductsInStockDTO() {
        return productRepository.findByStockQuantityGreaterThan(0).stream()
                .map(ProductMapper.INSTANCE::toDTO)
                .collect(Collectors.toList());
    }

    public void updateProductInformation(Long productId, Product product2) {
        Optional<Product> existingProduct = productRepository.findById(productId);
        existingProduct.ifPresent(product -> {
         
            product.setName(product2.getName());
            product.setPrice(product2.getPrice());
            product.setDescription(product2.getDescription());
            product.setStockQuantity(product2.getStockQuantity());

            productRepository.save(product);
        });
    }

    public boolean isProductAvailable(Long productId, int quantity) {
        Optional<Product> productOptional = productRepository.findById(productId);
        return productOptional.map(product -> product.getStockQuantity() >= quantity).orElse(false);
    }
    public void addToCart(Long productId, CartItemDTO cartItemDTO) {
        Product product = productRepository.findById(productId)
                .orElseThrow(() -> new RuntimeException("Product not found with id: " + productId));

        CartItem cartItem = convertCartItemToEntity(cartItemDTO);
        cartItem.setProduct(product);

        List<CartItem> cartItems = cartItemRepository.findAll();
        CartItem existingCartItem = cartItems.stream()
                .filter(item -> item.getProduct().getProductId().equals(productId))
                .findFirst()
                .orElse(null);

        if (existingCartItem != null) {
            existingCartItem.setQuantity(existingCartItem.getQuantity() + cartItem.getQuantity());
            cartItemRepository.save(existingCartItem);
        } else {
            cartItemRepository.save(cartItem);
        }
    }

    public List<CartItemDTO> viewCart() {
        List<CartItem> cartItems = cartItemRepository.findAll();

        return cartItems.stream()
                .map(this::convertCartItemToDto)
                .collect(Collectors.toList());
    }
    
    private CartItem convertCartItemToEntity(CartItemDTO cartItemDTO) {
        CartItem cartItem = new CartItem();
        cartItem.setId(cartItemDTO.getCartItemId());
        cartItem.setQuantity(cartItemDTO.getQuantity());


        return cartItem;
    }

    private CartItemDTO convertCartItemToDto(CartItem cartItem) {
        CartItemDTO cartItemDTO = new CartItemDTO();
        cartItemDTO.setCartItemId(cartItem.getId());
        cartItemDTO.setQuantity(cartItem.getQuantity());


        return cartItemDTO;
    }
    
    public Product convertProductToEntity(ProductDTO productDTO) {
        Product product = new Product();
        product.setProductId(productDTO.getProductId());
        product.setName(productDTO.getName());
        product.setPrice(productDTO.getPrice());
        product.setDescription(productDTO.getDescription());
        product.setStockQuantity(productDTO.getStockQuantity());


        return product;
    }

    private ProductDTO convertProductToDto(Product product) {
        ProductDTO productDTO = new ProductDTO();
        productDTO.setProductId(product.getProductId());
        productDTO.setName(product.getName());
        productDTO.setPrice(product.getPrice());
        productDTO.setDescription(product.getDescription());
        productDTO.setStockQuantity(product.getStockQuantity());


        return productDTO;
    }
	@PostConstruct
	public void initializeData() {

		Category electronicsCategory = new Category();
		electronicsCategory.setName("Electronics");

		Category clothingCategory = new Category();
		clothingCategory.setName("Clothing");

		Product laptop = new Product();
		laptop.setName("Laptop");
		laptop.setPrice(999.99);
		laptop.setDescription("High-performance laptop");
		laptop.setStockQuantity(10);
		laptop.setCategory(electronicsCategory);

		Product shirt = new Product();
		shirt.setName("Shirt");
		shirt.setPrice(19.99);
		shirt.setDescription("Casual shirt");
		shirt.setStockQuantity(50);
		shirt.setCategory(clothingCategory);

		electronicsCategory.getProducts().add(laptop);
		clothingCategory.getProducts().add(shirt);

		categoryRepository.save(electronicsCategory);
		categoryRepository.save(clothingCategory);
	}
}
