package com.project.cakmazon.services;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.cakmazon.dto.CustomerDTO;
import com.project.cakmazon.mapper.CustomerMapper;
import com.project.cakmazon.model.Customer;
import com.project.cakmazon.repo.CustomerRepository;

import jakarta.annotation.PostConstruct;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

@Service
public class CustomerService {

    @Autowired
    private CustomerRepository customerRepository;
    
    @Autowired
    private CustomerMapper customerMapper;

    public List<CustomerDTO> getAllCustomers() {
        List<Customer> customers = customerRepository.findAll();
        return customerMapper.toDTOList(customers);
    }

    public Optional<CustomerDTO> getCustomerById(Long customerId) {
        Optional<Customer> customer = customerRepository.findById(customerId);
        return customer.map(customerMapper::toDTO);
    }

    public CustomerDTO saveCustomer(CustomerDTO customerDTO) {
        Customer customer = customerMapper.toEntity(customerDTO);
        Customer savedCustomer = customerRepository.save(customer);
        return customerMapper.toDTO(savedCustomer);
    }

    public CustomerDTO updateCustomer(Long customerId, CustomerDTO updatedCustomerDTO) {
        Optional<Customer> existingCustomer = customerRepository.findById(customerId);
        if (existingCustomer.isPresent()) {
            Customer customerToUpdate = existingCustomer.get();
            customerToUpdate.setFirstName(updatedCustomerDTO.getFirstName());
            customerToUpdate.setLastName(updatedCustomerDTO.getLastName());
            customerToUpdate.setEmail(updatedCustomerDTO.getEmail());
            customerToUpdate.setAddress(updatedCustomerDTO.getAddress());

            Customer savedCustomer = customerRepository.save(customerToUpdate);
            return customerMapper.toDTO(savedCustomer);
        } else {
            throw new RuntimeException("Customer not found with id: " + customerId);
        }
    }

    public void deleteCustomer(Long customerId) {
        customerRepository.deleteById(customerId);
    }
    
    @PostConstruct
    public void initializeCustomers() {
        if (customerRepository.count() == 0) {
            Customer customer1 = new Customer();
            customer1.setFirstName("John");
            customer1.setLastName("Doe");
            customer1.setEmail("john.doe@example.com");
            customer1.setAddress("123 Main Street");

            Customer customer2 = new Customer();
            customer2.setFirstName("Jane");
            customer2.setLastName("Smith");
            customer2.setEmail("jane.smith@example.com");
            customer2.setAddress("456 Oak Avenue");

           
            customerRepository.saveAll(Arrays.asList(customer1, customer2));
        }
}
}
 
