package com.project.cakmazon.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.cakmazon.dto.CartItemDTO;
import com.project.cakmazon.dto.ProductDTO;
import com.project.cakmazon.mapper.CartItemMapper;
import com.project.cakmazon.mapper.ProductMapper;
import com.project.cakmazon.model.CartItem;
import com.project.cakmazon.model.Product;
import com.project.cakmazon.repo.CartItemRepository;

import jakarta.annotation.PostConstruct;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

@Service
public class CartItemService {

    @Autowired
    private CartItemRepository cartItemRepository;

    @Autowired
    private ProductService productService; 

    @Autowired
    private CartItemMapper cartItemMapper; 
    
    @Autowired
    private ProductMapper productMapper;

    public List<CartItemDTO> getAllCartItems() {
        List<CartItem> cartItems = cartItemRepository.findAll();
        return cartItemMapper.toDTOList(cartItems);
    }

    public Optional<CartItemDTO> getCartItemById(Long cartItemId) {
        Optional<CartItem> cartItem = cartItemRepository.findById(cartItemId);
        return cartItem.map(cartItemMapper::toDTO);
    }

    public void saveCartItem(CartItemDTO cartItemDTO) {
       
        ProductDTO product = productService.getProductDTOById(cartItemDTO.getProduct().getProductId());

        CartItem cartItem = cartItemMapper.toEntity(cartItemDTO);
        
        cartItem.setProduct(productMapper.toEntity(product));

        cartItemRepository.save(cartItem);
    }

    public void deleteCartItem(Long cartItemId) {
        cartItemRepository.deleteById(cartItemId);
    }
    
    public void updateCartItem(Long cartItemId, CartItemDTO updatedCartItemDTO) {
        CartItemDTO existingCartItem = getCartItemById(cartItemId)
                .orElseThrow(() -> new RuntimeException("CartItem not found with id: " + cartItemId));

        existingCartItem.setQuantity(updatedCartItemDTO.getQuantity());
        
        cartItemRepository.saveCartItem(existingCartItem);
    }
    
    @PostConstruct
    public void initializeCartItems() {
        if (cartItemRepository.count() == 0) {
            ProductDTO product1 = productService.getProductDTOById(1L);
            ProductDTO product2 = productService.getProductDTOById(2L);

            if (product1 != null && product2 != null) {
                CartItem cartItem1 = new CartItem();
                cartItem1.setProduct(productMapper.toEntity(product1));
                cartItem1.setQuantity(2); 
                CartItem cartItem2 = new CartItem();
                cartItem2.setProduct(productMapper.toEntity(product2));
                cartItem2.setQuantity(1);

                cartItemRepository.saveAll(Arrays.asList(cartItem1, cartItem2));
            }
        }
    }
}
